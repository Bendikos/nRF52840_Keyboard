# [keyboard]
cd /opt/zmk/app
sudo rm -r ./build
sudo west build -p -b nrfmicro_13 -- -DSHIELD=keyboard